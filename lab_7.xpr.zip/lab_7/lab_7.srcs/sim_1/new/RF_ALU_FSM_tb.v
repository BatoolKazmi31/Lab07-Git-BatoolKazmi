// RF_ALU_FSM_tb.v
// Integrated testbench: instantiates rf_alu_fsm (which itself instantiates
// the RegisterFile and the ALU), runs the whole sequence, and checks every
// destination register against its expected value at the end.

`timescale 1ns / 1ps

module RF_ALU_FSM_tb;

    reg clk;
    reg rst;
    wire [3:0]  state;
    wire [31:0] ALUResult_dbg;
    wire        Zero_dbg;

    rf_alu_fsm uut (
        .clk(clk),
        .rst(rst),
        .state(state),
        .ALUResult_dbg(ALUResult_dbg),
        .Zero_dbg(Zero_dbg)
    );

    always #5 clk = ~clk;   // 10 ns period

    task check (input [255:0] name, input [31:0] actual, input [31:0] expected);
        begin
            if (actual === expected)
                $display("PASS: %0s | got=%0h expected=%0h", name, actual, expected);
            else
                $display("FAIL: %0s | got=%0h expected=%0h", name, actual, expected);
        end
    endtask

    initial begin
        clk = 0;
        rst = 1;
        @(negedge clk);
        @(negedge clk);
        rst = 0;

        // Let the FSM run through all 14 states. Each state takes one clock
        // cycle, so give it generous margin: 20 cycles = 200 ns.
        repeat (20) @(posedge clk);
        #1; // let final writes settle

        $display("---- Final register contents ----");
        check("x1  (constant)",        uut.rf_inst.regs[1],  32'h10101010);
        check("x2  (constant)",        uut.rf_inst.regs[2],  32'h01010101);
        check("x3  (constant)",        uut.rf_inst.regs[3],  32'h00000005);
        check("x4  (ADD x1+x2)",       uut.rf_inst.regs[4],  32'h11111111);
        check("x5  (SUB x1-x2)",       uut.rf_inst.regs[5],  32'h0F0F0F0F);
        check("x6  (AND x1&x2)",       uut.rf_inst.regs[6],  32'h00000000);
        check("x7  (OR x1|x2)",        uut.rf_inst.regs[7],  32'h11111111);
        check("x8  (XOR x1^x2)",       uut.rf_inst.regs[8],  32'h11111111);
        check("x9  (SLL x1<<1)",       uut.rf_inst.regs[9],  32'h20202020);
        check("x10 (SRL x1>>1)",       uut.rf_inst.regs[10], 32'h08080808);
        check("x11 (BEQ flag, should be 1)", uut.rf_inst.regs[11], 32'd1);
        check("x12 (RAW write constant)",    uut.rf_inst.regs[12], 32'hAAAA5555);
        check("x13 (RAW read-back copy)",    uut.rf_inst.regs[13], 32'hAAAA5555);
        check("Final state is DONE",         state, 4'd14);

        $display("---- RF_ALU_FSM tests complete ----");
        $finish;
    end

endmodule