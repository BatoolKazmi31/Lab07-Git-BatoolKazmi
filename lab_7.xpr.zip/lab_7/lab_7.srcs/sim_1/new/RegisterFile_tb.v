// RegisterFile_tb.v
// Standalone testbench for RegisterFile.v
// Covers: basic write/read, x0 write-ignored, simultaneous dual read,
// overwrite, and reset behavior.
//
// Inputs are changed on the FALLING edge of clk (mid-cycle), and checked
// have settled well before the next rising edge. This avoids a
// race condition between the testbench driving signals and the DUT's
// own posedge-triggered write logic.

`timescale 1ns / 1ps

module RegisterFile_tb;

    reg         clk;
    reg         rst;
    reg         WriteEnable;
    reg  [4:0]  rs1, rs2, rd;
    reg  [31:0] WriteData;
    wire [31:0] ReadData1, ReadData2;

    RegisterFile uut (
        .clk(clk),
        .rst(rst),
        .WriteEnable(WriteEnable),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .WriteData(WriteData),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );

    always #5 clk = ~clk;   // 10 ns period

    task check (input [255:0] name, input [31:0] actual, input [31:0] expected);
        begin
            if (actual === expected)
                $display("PASS: %0s | got=%0h expected=%0h", name, actual, expected);
            else
                $display("FAIL: %0s | got=%0h expected=%0h", name, actual, expected);
        end
    endtask

    initial begin
        clk = 0;
        rst = 1;
        WriteEnable = 0;
        rs1 = 0; rs2 = 0; rd = 0; WriteData = 0;

        // ---- hold reset across a couple of edges ----
        @(negedge clk);
        @(negedge clk);
        rst = 0;

        // ---- Test (i): write to x5, then read it back ----
        @(negedge clk);              // change inputs mid-cycle, safely before next posedge
        rd = 5'd5;
        WriteData = 32'hDEADBEEF;
        WriteEnable = 1;
        @(posedge clk);              // DUT captures the write here
        @(negedge clk);              // move to a quiet point, then drop WE and read
        WriteEnable = 0;
        rs1 = 5'd5;
        #1;
        check("Write x5 then read via ReadData1", ReadData1, 32'hDEADBEEF);

        // ---- Test (ii): writing to x0 is ignored ----
        @(negedge clk);
        rd = 5'd0;
        WriteData = 32'hFFFFFFFF;
        WriteEnable = 1;
        @(posedge clk);
        @(negedge clk);
        WriteEnable = 0;
        rs1 = 5'd0;
        #1;
        check("x0 always reads 0 even after attempted write", ReadData1, 32'd0);

        // ---- Test (iii): simultaneous two reads ----
        @(negedge clk);
        rd = 5'd6;
        WriteData = 32'h12345678;
        WriteEnable = 1;
        @(posedge clk);
        @(negedge clk);
        WriteEnable = 0;
        rs1 = 5'd5;
        rs2 = 5'd6;
        #1;
        check("Simultaneous read port 1 (x5)", ReadData1, 32'hDEADBEEF);
        check("Simultaneous read port 2 (x6)", ReadData2, 32'h12345678);

        // ---- Test (iv): overwrite a register ----
        @(negedge clk);
        rd = 5'd5;
        WriteData = 32'h00000001;
        WriteEnable = 1;
        @(posedge clk);
        @(negedge clk);
        WriteEnable = 0;
        rs1 = 5'd5;
        #1;
        check("Overwrite x5 replaces old value", ReadData1, 32'h00000001);

        // ---- Test (v): reset clears registers again ----
        @(negedge clk);
        rst = 1;
        @(posedge clk);
        @(negedge clk);
        rst = 0;
        rs1 = 5'd5;
        rs2 = 5'd6;
        #1;
        check("After reset, x5 clears", ReadData1, 32'd0);
        check("After reset, x6 clears", ReadData2, 32'd0);

        $display("---- RegisterFile tests complete ----");
        $finish;
    end

endmodule