`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: top_rf_alu
// Lab 7 - Task 3: Register File + ALU + FSM, FPGA top level
//
// On power-up / reset, the FSM automatically:
//   - writes x1=0x10101010, x2=0x01010101, x3=0x00000005
//   - runs ADD, SUB, AND, OR, XOR, SLL, SRL on x1/x2, storing results in x4..x10
//   - does a BEQ-style Zero-flag check into x11
//   - does a read-after-write test into x12/x13
// Once finished (S_DONE), switches [3:0] let you manually pick any ALU
// operation to re-run live on x1/x2, so you can confirm results on the LEDs
// by hand during the demo to your RA.
//////////////////////////////////////////////////////////////////////////////////

module top_rf_alu (
    input  wire        clk,
    input  wire        pbin,           // reset button (restarts the whole demo)
    input  wire [15:0] physical_sw,
    output wire [15:0] physical_leds
);

    // ============================================================
    // LAB 5 INTERFACE (reused, same wiring as Lab 6)
    // ============================================================

    wire rst_clean;
    wire [31:0] switch_data;
    reg  [31:0] led_write_data;

    debouncer rst_db (
        .clk(clk),
        .reset(1'b0),
        .btn_in(pbin),
        .btn_out(rst_clean)
    );

    leds switch_reader (
        .clk(clk),
        .rst(1'b0),
        .btns(16'd0),
        .writeData(32'd0),
        .writeEnable(1'b0),
        .readEnable(1'b1),
        .memAddress(30'd0),
        .switches(physical_sw),
        .readData(switch_data)
    );

    switches led_writer (
        .clk(clk),
        .rst(1'b0),
        .writeData(led_write_data),
        .writeEnable(1'b1),
        .readEnable(1'b0),
        .memAddress(30'd0),
        .readData(),
        .leds(physical_leds)
    );

    // ============================================================
    // REGISTER FILE + ALU + FSM
    // ============================================================

    wire [3:0]  state;
    wire [31:0] ALUResult_dbg;
    wire        Zero_dbg;

    rf_alu_fsm uut (
        .clk(clk),
        .rst(rst_clean),
        .manual_ALUControl(switch_data[3:0]),  // only acts once FSM reaches S_DONE
        .state(state),
        .ALUResult_dbg(ALUResult_dbg),
        .Zero_dbg(Zero_dbg)
    );

    // ============================================================
    // LED OUTPUT
    // LED[15:12] = FSM state (0-14, fits in 4 bits)
    // LED[11]    = Zero flag
    // LED[10:0]  = lower 11 bits of the current ALU result
    // ============================================================

    always @(*) begin
        led_write_data = {16'd0, state, Zero_dbg, ALUResult_dbg[10:0]};
    end

endmodule