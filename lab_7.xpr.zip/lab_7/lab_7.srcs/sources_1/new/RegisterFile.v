// RegisterFile.v
// 32 x 32 register file, RISC-V (RV32I) convention:
//   - x0 is hardwired to 0: always reads 0, writes to it are ignored.
//   - Two asynchronous (combinational) read ports.
//   - One synchronous write port (write happens on the rising clock edge).

module RegisterFile (
    input         clk,
    input         rst,
    input         WriteEnable,
    input  [4:0]  rs1,
    input  [4:0]  rs2,
    input  [4:0]  rd,
    input  [31:0] WriteData,
    output [31:0] ReadData1,
    output [31:0] ReadData2
);

    // 32 registers, each 32 bits wide
    reg [31:0] regs [31:0];

    // ---- Asynchronous reads ----
    // x0 always reads as 0, no matter what is stored there.
    assign ReadData1 = (rs1 == 5'd0) ? 32'd0 : regs[rs1];
    assign ReadData2 = (rs2 == 5'd0) ? 32'd0 : regs[rs2];

    // ---- Synchronous write, with reset ----
    integer i;
    always @(posedge clk) begin
        if (rst) begin
            // clear every register on reset
            for (i = 0; i < 32; i = i + 1)
                regs[i] <= 32'd0;
        end
        else if (WriteEnable && rd != 5'd0) begin
            // writes to x0 are ignored - rd==0 is excluded here
            regs[rd] <= WriteData;
        end
    end

endmodule