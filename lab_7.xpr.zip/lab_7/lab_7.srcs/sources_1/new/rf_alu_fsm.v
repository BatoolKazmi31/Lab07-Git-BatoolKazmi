// rf_alu_fsm.v
// Instantiates RegisterFile and ALU, and drives them with an FSM that:
//   1. Writes known constants into x1, x2, x3
//   2. Reads x1, x2 and runs ADD, SUB, AND, OR, XOR, SLL, SRL through the ALU,
//      writing each result into x4..x10
//   3. Does a BEQ-style check (SUB of a register with itself -> Zero flag)
//      and writes a flag register (x11) based on that flag
//   4. Writes a known value into x12, then reads it back the very next cycle
//      and copies it to x13, to demonstrate read-after-write timing
//   5. Sits in DONE (useful for simulation; on hardware this can loop back
//      to IDLE instead, see the commented line below)

module rf_alu_fsm (
    input         clk,
    input         rst,
    input  [3:0]  manual_ALUControl,  // only used once FSM reaches S_DONE (see below)
    output [3:0]  state,        // exposed for waveform viewing / LEDs
    output [31:0] ALUResult_dbg,
    output        Zero_dbg
);

    // ---- States ----
    localparam S_IDLE        = 4'd0;
    localparam S_WRITE_X1    = 4'd1;
    localparam S_WRITE_X2    = 4'd2;
    localparam S_WRITE_X3    = 4'd3;
    localparam S_COMPUTE_ADD = 4'd4;
    localparam S_COMPUTE_SUB = 4'd5;
    localparam S_COMPUTE_AND = 4'd6;
    localparam S_COMPUTE_OR  = 4'd7;
    localparam S_COMPUTE_XOR = 4'd8;
    localparam S_COMPUTE_SLL = 4'd9;
    localparam S_COMPUTE_SRL = 4'd10;
    localparam S_BEQ_CHECK   = 4'd11;
    localparam S_RAW_WRITE   = 4'd12;
    localparam S_RAW_READ    = 4'd13;
    localparam S_DONE        = 4'd14;

    reg [3:0] current_state, next_state;
    assign state = current_state;

    always @(posedge clk) begin
        if (rst)
            current_state <= S_IDLE;
        else
            current_state <= next_state;
    end

    // ---- ALUControl encoding, must match ALU.v ----
    localparam ALU_AND = 4'b0000;
    localparam ALU_OR  = 4'b0001;
    localparam ALU_ADD = 4'b0010;
    localparam ALU_XOR = 4'b0011;
    localparam ALU_SLL = 4'b0100;
    localparam ALU_SRL = 4'b0101;
    localparam ALU_SUB = 4'b0110;

    // ---- RegisterFile / ALU connections, driven per-state below ----
    reg         WriteEnable;
    reg  [4:0]  rs1, rs2, rd;
    reg  [31:0] WriteData;
    reg  [3:0]  ALUControl;

    wire [31:0] ReadData1, ReadData2;
    wire [31:0] ALUResult;
    wire        Zero;

    assign ALUResult_dbg = ALUResult;
    assign Zero_dbg       = Zero;

    RegisterFile rf_inst (
        .clk(clk),
        .rst(rst),
        .WriteEnable(WriteEnable),
        .rs1(rs1),
        .rs2(rs2),
        .rd(rd),
        .WriteData(WriteData),
        .ReadData1(ReadData1),
        .ReadData2(ReadData2)
    );

    ALU alu_inst (
        .A(ReadData1),
        .B(ReadData2),
        .ALUControl(ALUControl),
        .ALUResult(ALUResult),
        .Zero(Zero)
    );

    // ---- Combinational control: what each state does, and where it goes next ----
    always @(*) begin
        // safe defaults every state, overridden below where needed
        WriteEnable = 0;
        rs1 = 5'd0;
        rs2 = 5'd0;
        rd  = 5'd0;
        WriteData  = 32'd0;
        ALUControl = ALU_ADD;
        next_state = current_state;

        case (current_state)

            S_IDLE: begin
                next_state = S_WRITE_X1;
            end

            S_WRITE_X1: begin
                rd = 5'd1; WriteData = 32'h10101010; WriteEnable = 1;
                next_state = S_WRITE_X2;
            end

            S_WRITE_X2: begin
                rd = 5'd2; WriteData = 32'h01010101; WriteEnable = 1;
                next_state = S_WRITE_X3;
            end

            S_WRITE_X3: begin
                rd = 5'd3; WriteData = 32'h00000005; WriteEnable = 1;
                next_state = S_COMPUTE_ADD;
            end

            S_COMPUTE_ADD: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_ADD;
                rd = 5'd4; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_COMPUTE_SUB;
            end

            S_COMPUTE_SUB: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_SUB;
                rd = 5'd5; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_COMPUTE_AND;
            end

            S_COMPUTE_AND: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_AND;
                rd = 5'd6; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_COMPUTE_OR;
            end

            S_COMPUTE_OR: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_OR;
                rd = 5'd7; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_COMPUTE_XOR;
            end

            S_COMPUTE_XOR: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_XOR;
                rd = 5'd8; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_COMPUTE_SLL;
            end

            S_COMPUTE_SLL: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_SLL;
                rd = 5'd9; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_COMPUTE_SRL;
            end

            S_COMPUTE_SRL: begin
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = ALU_SRL;
                rd = 5'd10; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_BEQ_CHECK;
            end

            S_BEQ_CHECK: begin
                // SUB a register with itself -> result is always 0 -> Zero = 1
                // This mirrors how a real BEQ compares two operands via SUB+Zero.
                rs1 = 5'd1; rs2 = 5'd1; ALUControl = ALU_SUB;
                rd = 5'd11;
                WriteData = Zero ? 32'd1 : 32'd0;  // flag register: 1 = "branch taken"
                WriteEnable = 1;
                next_state = S_RAW_WRITE;
            end

            S_RAW_WRITE: begin
                rd = 5'd12; WriteData = 32'hAAAA5555; WriteEnable = 1;
                next_state = S_RAW_READ;
            end

            S_RAW_READ: begin
                // read x12 (written just last cycle) and copy it to x13 via
                // ALU OR with x0 (always 0), proving read-after-write works
                rs1 = 5'd12; rs2 = 5'd0; ALUControl = ALU_OR;
                rd = 5'd13; WriteData = ALUResult; WriteEnable = 1;
                next_state = S_DONE;
            end

            S_DONE: begin
                // Demo sequence is finished. Re-use the same ALU, read-only,
                // so switches can be used to manually try any operation on
                // the x1/x2 constants and watch the LEDs update live.
                // No WriteEnable here, so this can never disturb the
                // register values that were just verified in simulation.
                rs1 = 5'd1; rs2 = 5'd2; ALUControl = manual_ALUControl;
                WriteEnable = 0;
                next_state = S_DONE;   // on hardware you could use S_IDLE here to loop the demo instead
            end

            default: begin
                next_state = S_IDLE;
            end

        endcase
    end

endmodule